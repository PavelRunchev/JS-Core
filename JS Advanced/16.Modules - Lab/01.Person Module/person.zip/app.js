let Person = require('./person');

result.Person = Person;

//example
//let person = new Person("Pavel");
//console.log(person.toString());