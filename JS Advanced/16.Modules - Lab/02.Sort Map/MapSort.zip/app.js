const mapSort = require('./mapSort');

result.mapSort = require('./mapSort');

//example
/*
let map = new Map();
map.set(6, "Pesho");
map.set(5, "Gosho");
map.set(1, "Aleks");

console.log(mapSort(map));
*/

