$(() => {
    const app = Sammy('#app', function () {
        this.use('Handlebars', 'hbs');


        this.get('index.html', function (ctx) {
            ctx.loadPartials({
                navigation: './templates/common/header.hbs',
                page: './templates/forms/login.hbs',
                footer: './templates/common/footer.hbs'
            }).then(function () {
                this.partial('./templates/main.hbs');
            });
        });

        this.post('#/login', function (ctx) {
            let username = ctx.params.username;
            let password = ctx.params.pass;

            if(username === '' || password === '') {
                return notify.showError("Input fields cannot be empty!");
            }

            auth.login(username, password).then(function (userData) {
                auth.saveSession(userData);
                notify.showInfo("Login successful.");
                ctx.redirect('#/catalog');

            }).catch(notify.handleError);
        });

        this.post('#/register', function (ctx) {
            let username = ctx.params.username;
            let password = ctx.params.pass;
            let repeatPass = ctx.params.checkPass;

            if(username.length < 5) {
                return notify.showError("Username should be a string with at least 5 symbols long!");
            } else if (password === '') {
                return notify.showError("Passwords input fields shouldn’t be empty!");
            } else if (repeatPass !== password) {
                return notify.showError("Both passwords should match!");
            }

            auth.register(username, password)
                .then(function (userData) {
                    auth.saveSession(userData);
                    notify.showInfo("User registration successful.");
                    ctx.redirect('#/catalog');
                }).catch(notify.handleError);

        });

        this.get('#/logout', function (ctx) {
            auth.logout().then(function () {
                sessionStorage.clear();
                notify.showInfo("Logout successful.");
                ctx.redirect('#');
            }).catch(notify.handleError);
        });
    });

    app.run();
});
